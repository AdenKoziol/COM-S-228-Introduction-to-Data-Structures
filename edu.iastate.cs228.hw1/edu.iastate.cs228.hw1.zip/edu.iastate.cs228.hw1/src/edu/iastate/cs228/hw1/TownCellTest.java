package edu.iastate.cs228.hw1;
import static edu.iastate.cs228.hw1.TownCell.NUM_CELL_TYPE;
import static org.junit.jupiter.api.Assertions.*;
import org.junit.jupiter.api.Test;

/**
 * @author Aden Koziol
 */
public class TownCellTest
{
    @Test
    void test()
    {
        //You can't reference census() from this class I don't understand how you can test it.
    }
}
